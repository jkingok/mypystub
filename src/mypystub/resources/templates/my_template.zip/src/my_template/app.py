from pathlib import Path
import toga

from . import ui

class MyApp(toga.App):
    def startup_into(app):
        """Construct and show the Toga application.

        Usually, you would add your application to a main content box.
        We then create a main window (with a name matching the app), and
        show the main window.
        """
        app.proto = ui.Prototype(host_app=app, on_done=lambda _: MyApp.unstack_from(app))

        # Update window context and inject the prototype layout
        t = getattr(app.proto, "title", app.formal_name)
        if not app.main_window:
            app.main_window = toga.MainWindow(title=t)
        mw = app.main_window
        if mw.content:
            if not hasattr(mw, "content_stack"):
                mw.content_stack = []
            mw.content_stack.append((mw.title, mw.content))
        mw.title = t
        mw.content = app.proto.get_content()
        if not mw.visible:
            mw.show()

    def unstack_from(app):
        if hasattr(app.main_window, "content_stack") and len(app.main_window.content_stack) > 0:
            t, c = app.main_window.content_stack.pop()
            app.main_window.title = t
            app.main_window.content = c

    def startup(self):
        return MyApp.startup_into(self)

def main():
    if not (a := toga.App.app):
        return MyApp()
    elif a.loop:
        a.loop.call_soon(lambda a=a: MyApp.startup_into(a))
    else:
        MyApp.startup_into(a) 
    return None
